import cv2
import pickle

from rich import print
from aruco_utils import pose_estimation

aruco_type = cv2.aruco.DICT_5X5_100
aruco_dict = cv2.aruco.getPredefinedDictionary(aruco_type)
aruco_params = cv2.aruco.DetectorParameters()

cam_stream = cv2.VideoCapture(0)

with open('./calibration/out/calibration.pkl', 'rb') as f:
    (camera_matrix, distortion_coefficients) = pickle.load(f)
    
while True:

    (is_frame, frame) = cam_stream.read()

    if not is_frame:
        continue
        
    detected_markers = pose_estimation(frame, aruco_dict, aruco_params, camera_matrix, distortion_coefficients)
    print(detected_markers)
    
    cv2.imshow('Pose estimation', frame)
        
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
    
cam_stream.release()
cv2.destroyAllWindows()